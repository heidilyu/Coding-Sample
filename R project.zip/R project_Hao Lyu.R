# Coding Sample
## submit to Evidence in Governance and Politics (EGAP) and Institute of Government Studies
## written by Hao Lyu

## Overview: 
### This project aims to present codings for a research process. 
### It includes 4 parts: data cleaning, descriptive analysis and visualization, econometric analysis, and Machine Learning 
### Data retrieved from World Bank World Development Indicator(WDI) database. 

# SET UP ------------------------------------------------------------
library(dplyr)
library(tidyr)
library(ggplot2)
library(stargazer)
library(car)

## Note: please rewrite the working directory 
setwd("/Users/haolyu/Documents/Job Hunting/11-dime spring drive/R project") 
WDIData <- readRDS("WDIData.Rds")
WDICountry <- readRDS("WDICountry.Rds")

### WDICountry includes country codes and indicators that are useful for subsetting
### WDIData is the raw WDI database (1600 variables * 56 years * 265 countries and groups)

# 1 CLEANING ------------------------------------------------------------
## Clean WDICountry file
wdi_country <- select(WDICountry, Country.Code, Region, Income.Group)
names(wdi_country)[1:3] <- c("country_code", "region", "income_group")

## Clean WDIData file: rename variables, remove the extraneous "X" column
wdi_full <- select(WDIData, -X)
names(wdi_full)[1:4] <- c("country", "country_code", "indicator", "indicator_code")

## Trim down WDI dataset, before reshaping 
indics <- c('SE.SEC.UNER.LO.FE.ZS', 'SE.SEC.UNER.LO.MA.ZS', 'SL.TLF.0714.ZS', 'IQ.CPA.BREG.XQ', 'IQ.CPA.FISP.XQ',
            'IQ.CPA.GNDR.XQ', 'IQ.CPA.TRAN.XQ', 'NY.GDP.MKTP.CD', 'NY.GDP.PCAP.CD', 'NY.GDP.PCAP.KD.ZG', 
            'SI.POV.GINI', 'SE.XPD.TOTL.GB.ZS', 'SP.DYN.IMRT.IN', 'SI.POV.GAPS', 'SI.POV.LMIC.GP', 
            'SI.POV.UMIC.GP', 'GB.XPD.RSDV.GD.ZS', 'SE.PRM.NENR', 'IC.LGL.CRED.XQ', 'GC.TAX.TOTL.GD.ZS', 'GC.TAX.YPKG.RV.ZS')

wdi_subset <- 
  wdi_full %>%
  select(country, country_code, indicator_code, X1980:X2016) %>%
  filter(indicator_code %in% indics)

## reshape dataframe 
wdi_long <- gather(wdi_subset, key = "year", value = "value", X1980:X2016)
wdi_vars_long <- spread(wdi_long, key= indicator_code, value=value)

## merge WDICountry
wdi_all_vars <- left_join(wdi_vars_long, wdi_country, by = "country_code")

## Clean the year variable, remove observations that are not about countries, i.e. ‘IDA only', 'Caribbean small states', etc
wdi_clean <-
  wdi_all_vars %>%
  select(country, country_code, year, region, income_group, all_of(indics)) %>%
  mutate(year = as.Date(paste0(gsub("X", "", year), "-01-01"))) %>%
  filter(!region == "" & !is.na(region) & !income_group == "" & !is.na(income_group)) %>%
  arrange(country, year)

## Create a codebook and label variables 
indicator_code <- data.frame(
  id = c(1:26),
  indicator_code = colnames(wdi_clean),
  stringsAsFactors = F)

indicator <- 
  wdi_full%>%
  select(indicator, indicator_code)
indicator = (unique(indicator))

codebook <- left_join(indicator_code, indicator, by = 'indicator_code', all.x=F)

names(wdi_clean)[6:26]<-c('school_drop_f', 'school_drop_m', 'child_worker', 'business_rating', 'fiscal',
                          'gender', 'transparency', 'gdp', 'gdppc', 'gdppc_growth', 
                          'gini', 'educ_exp', 'infant_mortality', 'poverty_19', 'poverty_32',
                          'poverty_55', 'rdexpend', 'school_enroll', 'legal', 'tax_total', 'tax_income')

variable <- data.frame(
  id = c(1:26),
  variable_name = colnames(wdi_clean),
  stringsAsFactors = F)

codebook <- left_join(codebook, variable, by = 'id', all.x=F)

## Export data and the codebook
write.csv(wdi_clean, "wdi_clean.csv", row.names=FALSE)
write.csv(codebook,'Code Book.csv',row.names = FALSE)

# 2 DESCRIPTIVE ANALYSIS & VISUALIZATION------------------------------------------------------------

## Report the number of unique countries, regions, and Income groups
obs <- data.frame(
  country = length(unique(wdi_clean$country)), 
  region = length(unique(wdi_clean$region)), 
  income_group = length(unique(wdi_clean$income_group)),
  stringsAsFactors = F
)
obs 

## Or generate a summary statistics table 
label <- c('Adolescents out of school, fmale (%)', 'Adolescents out of school, male (%)', 'Children in employment (%)',
           'CPIA business regulatory environment rating', 'CPIA fiscal policy rating', 'CPIA gender equality rating',
           'CPIA transparency, accountability, and corruption rating', 'GDP (US$)', 'GDP per capita (US$)', 'GDP per capita growth (annual %)',
           'GINI index (World Bank estimate)', 'Government expenditure on education (% of government expenditure)', 'Mortality rate, infant (per 1,000 live births)',
           'Poverty gap at $1.90 a day (2011 PPP) (%)', 'Poverty gap at $3.20 a day (2011 PPP) (%)', 'Poverty gap at $5.50 a day (2011 PPP) (%)',
           'Research and development expenditure (% of GDP)', 'School enrollment, primary (% net)', 'Strength of legal rights index (0=weak to 12=strong)',
           'Tax revenue (% of GDP)', 'Taxes on income, profits and capital gains (% of revenue)')

stargazer(wdi_clean, title = 'Table 1 Summary Statistics of WDI Dataset 1980-2016',
          out = 'table1.txt', digits = 2, covariate.labels = all_of(label))

## Report the region that has the highest incidence of observations in the "Upper middle income" income group
max_region_umi <-
  wdi_clean %>%
  filter(income_group == "Upper middle income")%>%
  group_by(region)%>%
  summarise(n_high_incid = n())%>%
  ungroup%>%
  filter(n_high_incid == max(n_high_incid))
max_region_umi

## Report the average infant mortality rate for the time horizon in each country 
wdi_imr<- filter(wdi_clean, !infant_mortality == "" & !is.na(infant_mortality))

avg_imr_bycountry <-
  wdi_imr %>%
  group_by(country)%>%
  summarise(avg_imr = mean(infant_mortality, na.rm = T))%>%
  ungroup%>%
  arrange(avg_imr)
avg_imr_bycountry 

## Filter out NA values for the R&D expenditure variable and store it as a new dataframe
r_and_d_exp <-
  wdi_clean%>%
  select(country, country_code, region, year, income_group, rdexpend)%>%
  filter(!is.na(rdexpend)&!rdexpend =="")
str(r_and_d_exp)

## Draw a time series plot of the average R&D expenditure variable from each year
avg_r_and_d_byyear <-
  r_and_d_exp%>%
  group_by(year)%>%
  summarise(mean(rdexpend))

names(avg_r_and_d_byyear) <- c("Year", "Average_R_And_D_Expenditure")

jpeg("figure1.jpg", width = 600, height = 350)
plot(avg_r_and_d_byyear$Year,
     avg_r_and_d_byyear$Average_R_And_D_Expenditure,
     xlab = "Year", ylab = "Average R&D Expenditure", col = 1006, main = "Time Series Plot of the Average R&D Expenditure",
     type = "l")
dev.off()

# Draw a time series plot of the average GDP per capita of each region for the time horizon
region_year <- 
  wdi_clean%>%
  group_by(region, year)%>%
  summarise(enroll = mean(school_enroll, na.rm = T), 
            imr = mean(infant_mortality, na.rm = T),
            gdp = mean(gdppc, na.rm = T),
            rnd = mean(rdexpend, na.rm = T),
            bur = mean(business_rating, na.rm = T))

jpeg("figure2", width = 600, height = 350)
ggplot(region_year, aes(x=year, y=gdp, col=region))+
  geom_line(size=1) +
  labs(x = "Year", 
       y = "GDP per capita (current US$)", 
       title = "Time Series Plot of GDP Per Capita of Each Region 1980-2016")
dev.off()

## Draw a histogram of primary school enrollment in 2016 with separate graphs for each region
wdi_2016 <- filter(wdi_clean, wdi_clean$year >= "2016-01-01")

wdi_pse_byregion <- 
  wdi_2016 %>%
  select(school_enroll, region) 
filter(wdi_pse_byregion, !wdi_pse_byregion$school_enroll == ""& !is.na(wdi_pse_byregion$school_enroll)&!wdi_pse_byregion$region == ""& !is.na(wdi_pse_byregion$region))

names(wdi_pse_byregion) <- c("primary_school_enrollment", "region")

jpeg("figure3", width = 532, height = 424)
ggplot(wdi_pse_byregion, aes(x=primary_school_enrollment, fill=factor(region)))+
  geom_histogram(bins = 30) +
  facet_wrap(~factor(region)) +
  labs(x ="Primary School Enrollment (% net)", y="Frequency", title = "Histogram of Primary School Enrollment in 2016, by region")+
  scale_fill_discrete(name = "Region")
dev.off()

## Plot the relationship between infant mortality and GDP per capita between 2011 and 2016 
## and single out Sub-Saharan Africa 
wdi_11 <- filter(wdi_clean, wdi_clean$year >= "2011-01-01")

wdi_11$year2 <- substring(wdi_11$year,1,4)

wdi_11 = subset(wdi_11, select = -c(year))

wdi_11 <- 
  wdi_11%>%
  rename (year = year2)

jpeg("figure4.jpg", width = 614, height = 424)
wdi_11 %>%
  mutate(
    ssa = ifelse(region== "Sub-Saharan Africa", TRUE, FALSE)
  )%>%
  ggplot(aes(x=gdppc, y=infant_mortality, color=ssa, shape = ssa))+
  geom_point()+
  facet_wrap(~factor(year))+
  scale_color_discrete(labels = c("Sub-Saharan Africa", "Other regions"))+
  labs(x="GDP per capita", 
       y="Infant Mortality Rate",
       color = "Region",
       title="Infant mortality and GDP per capita, 2011-2016")+
  theme_minimal()
dev.off()

## Plot a box plot of fiscal and total tax revenue
wdi_11$fiscal <- as.factor(wdi_11$fiscal)

jpeg("figure5.jpg", width = 614, height = 424)
wdi_11 %>% 
  filter(!is.na(fiscal))%>%
  mutate(highlight = ifelse(fiscal == '3.5', "Highlighted", "Normal"))%>%
  ggplot(aes(x=fiscal, y=tax_total, fill = highlight, alpha = highlight))+
    geom_boxplot()+
    scale_fill_manual(values = c("#4797c9", "grey"))+
    scale_alpha_manual(values = c(1,0.1))+
    theme_minimal() +
    theme(legend.position = "none") +
    labs(x="CPIA fiscal policy rating (1=low to 6=high)", 
       y="Tax revenue (% of GDP)",
       title="Fiscal Policy Rating and Tax Revenue (% GDP), 2011-2016", 
       caption = "The mean of Fiscal Policy Rating is equal to 3.34. Thus, I highlight the box of the observations scored '3.5'.")
dev.off()


# 3 ECONOMETRICS ANALYSIS ------------------------------------------------------------
library(haven)
library(MASS)
library(lmtest)
library(plm)
library(multiwayvcov) 
library(randomForest)

## Research Question: what are the factors affect the rate of 'female adolescents out of school'? 

## OLS regressions (with robust standard error and region cluster) 
linear.1 <- lm(infant_mortality ~ gdppc + gender + educ_exp + poverty_55, data = wdi_clean) 

residuals<-rstudent(linear.1)
yhat<-fitted(linear.1)
par(mfrow=c(1,2))

jpeg("figure6.jpg", width = 614, height = 424)
plot(yhat, residuals)
abline(h=c(-2,2), col=2,lty=2)
dev.off()

linear.2 <- rlm(infant_mortality ~ gdppc + gender + educ_exp + poverty_55, data = wdi_clean) 

linear.3 <- coeftest(linear.1, vcov. = vcovHC(linear.1, type = "HC1", cluster="region"))

## Fixed-effects model 
linear.4 <- plm(infant_mortality ~ gdppc + gender + educ_exp + poverty_55, 
                data=wdi_clean, model="within", index="region") 

linear.5 <- plm(infant_mortality ~ gdppc + gender + educ_exp + poverty_55, 
                data=wdi_clean, model="within", index="year") 

linear.6 <- plm(infant_mortality ~ gdppc + gender + educ_exp + poverty_55, 
                data=wdi_clean, model="within", index=c("year", "country"), effect = "twoways")

## regression output
stargazer(linear.1, linear.2, linear.3, 
          title="OLS Regression Output", align=TRUE, 
          dep.var.labels="Infant Mortality Rate",
          covariate.labels=c("GDP per capita","CPIA gender equality rating",
                             "Government expenditure on education","Poverty gap at $5.50 a day"),
          add.lines = list(c("Robust", "No", "Yes","No"),
                           c("Cluster", "No", "No","Yes")),
          multicolumn = TRUE,
          omit.stat=c("LL","ser"), style = "aer", no.space=TRUE)

stargazer(linear.1, linear.4, linear.5, linear.6, 
          title="Fixed-effects Models Regression Output", align=TRUE, 
          dep.var.labels="Infant Mortality Rate",
          covariate.labels=c("GDP per capita","CPIA gender equality rating",
                             "Government expenditure on education","Poverty gap at $5.50 a day"),
          add.lines = list(c("Fixed effects", "No", "Yes","Yes","Yes"),
                           c("Fixed effects", "", "region","year","country-year")),
          column.labels   = c("OLS", "Fixed Effects"),
          column.separate = c(1,3),
          column.sep.width = "3pt",
          omit.stat=c("LL","ser"), style = "aer",  no.space=TRUE)

# 4 MACHINE LEARNING------------------------------------------------------------

## Let's use survey data to try a random forest model! 
survey <- read_dta("South Africa Survey 2008_cleaned.dta")

keep<- c('happy','income', 'work_hrs','pop_group', 'age', 'gender', 'marriage', 'educ','phone')
survey = survey[keep]
survey <- na.omit(survey)

cols <- c('pop_group', 'gender', 'marriage', 'educ')
survey[cols] <- lapply(survey[cols], factor)

cols.n <- c('income', 'work_hrs')
survey[cols.n] <- sapply(survey[cols.n], as.numeric)

survey$happyf <- as.factor(survey$happy)
sapply(survey, class)

## set up rmse
rmse <- function(predicted, observed) {
  return(sqrt(sum((predicted - observed)^2)/length(observed)))
}
  
## Probit model
probit <- glm(happy ~ income + work_hrs + gender + marriage + age + pop_group + educ + phone
              , data=survey, family = binomial(link = "probit"))
pred_probit <- predict(probit, type='response')
### Accuracy metrics:
happy_pred <- ifelse(pred_probit >0.5, "1","0")
in_acc <- mean(happy_pred == survey$happy)
in_acc 

## Random forest model
set.seed(100)
train <- sample(1:nrow(survey), 100)
metrics <- numeric(length=64L)
for (mtry in seq_along(metrics)) {
  message(glue::glue('Fitting randomForest models with {mtry} variable(s) per split'))
  rf <- randomForest(happy ~ ., 
                     data=survey, subset = train, mtry = mtry, ntree = 500)
  pred <- predict(rf, survey[-train, ])
  metrics[mtry] <- rmse(predicted=pred, observed=survey$happy)
}
min(metrics)               

probit <- glm(happy ~ income + work_hrs + gender + marriage + age + pop_group + educ + phone, 
              data=survey, family = binomial(link = "probit"))
pred_probit2 <- predict(probit, newdata = survey[-train,])
rmse(pred_probit2, survey$happy[-train])
### randomforest model has a lower rmse(0.394) compared to probit model.


# ---------------------------------------------------------------------
paste("The end of the project", 
      "Thank you for reviewing Hao's work." ,
      "I am looking forward to working with you this fall.")

